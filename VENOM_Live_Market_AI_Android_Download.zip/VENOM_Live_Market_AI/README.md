# VENOM LIVE MARKET AI (Python)
## Run
1. Install Python 3.10+.
2. In this folder run: `pip install -r requirements.txt`
3. Start: `streamlit run app.py`
4. Enter your Twelve Data API key in the sidebar. Alternatively set `TWELVE_DATA_API_KEY` before starting.
   - Windows PowerShell: `$env:TWELVE_DATA_API_KEY="YOUR_KEY"`
   - macOS/Linux: `export TWELVE_DATA_API_KEY="YOUR_KEY"`

## Markets
EUR/USD, GBP/USD, USD/JPY, AUD/USD, XAU/USD (Gold), WTI/USD (Crude Oil).
Provider coverage and subscription access vary. If WTI/USD is unavailable, check Twelve Data's current symbol catalogue for a supported crude-oil instrument.

## Notes
- Pulls OHLC candles using Twelve Data REST time-series API.
- Refresh speed, history access, and symbols depend on your provider plan.
- Five-minute signal refresh is not a guaranteed five-minute trade result.
- Rules combine EMA 9/21, RSI 14, MACD and previous-candle breakout. WAIT is shown when conditions conflict; forcing BUY/SELL in every condition would be misleading.
- Keep API keys private; do not hard-code or commit them.
